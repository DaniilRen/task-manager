package org.intb.entity;

public enum TaskStatus {
    ASSIGNED,
    IN_WORK,
    DONE
}
