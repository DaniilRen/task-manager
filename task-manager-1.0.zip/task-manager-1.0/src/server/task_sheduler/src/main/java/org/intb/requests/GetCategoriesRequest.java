package org.intb.requests;

public class GetCategoriesRequest {
}
