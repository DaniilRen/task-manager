package org.intb.requests.blob;

public class DeleteBlobRequest {

    private Long blobId;

    public Long getBlobId() {
        return blobId;
    }

    public void setBlobId(Long blobId) {
        this.blobId = blobId;
    }
}
