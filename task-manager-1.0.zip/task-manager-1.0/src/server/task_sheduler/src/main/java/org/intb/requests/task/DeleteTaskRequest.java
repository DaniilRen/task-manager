package org.intb.requests.task;

public class DeleteTaskRequest {

    private long taskID;

    public long getTaskID() {
        return taskID;
    }

    public void setTaskID(long taskID) {
        this.taskID = taskID;
    }
}
