package org.intb.requests.user;

public class DeleteUserRequest {

    private long userID;

    public long getUserID() {
        return userID;
    }

    public void setUserID(long userID) {
        this.userID = userID;
    }
}
