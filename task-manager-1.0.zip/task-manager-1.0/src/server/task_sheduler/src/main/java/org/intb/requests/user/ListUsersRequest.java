package org.intb.requests.user;

public class ListUsersRequest {
}
