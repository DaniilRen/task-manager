package org.intb.response;

import java.util.List;
import java.util.Set;

public class GetCategoriesResponse {

    private Set<String> categories;

    public Set<String> getCategories() {
        return categories;
    }

    public void setCategories(Set<String> categories) {
        this.categories = categories;
    }
}
